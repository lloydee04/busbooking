import React from 'react'
import './css/header.css'
import Home from './home'
import Routes from './Routes';
import Tickets from './tickets';
import Payment from './payment'
import { Route, BrowserRouter as Router, Switch } from 'react-router-dom'
import Notfound from './notfound'; //if no route found it will just directly into Notfound component
import {Navbar , Nav , Container , Modal , Form , Row , Col} from 'react-bootstrap';
import busicon from './bus-icon.png';
import Receipt from './Receipt';


//global scope validation message
function ValidationMessage(props){
    if(!props.valid){
      return(
        <div className='error-msg'>
          {props.message}
        </div>
      )
    }
    return null
  }


class Header extends React.Component{
    constructor(){
        super()
        this.state= { 
            userDetails: [],
            ModalShowLogin : false,
            ModalShowRegister: false,
            isLoggedin: false,
            username:'',
            password:'',
            firstName:'',
            lastName:'',
        }
    }

    handleSubmit= () => {
        let userDetails = {
            username: this.state.username,
            password: this.state.password,
            firstName: this.state.firstName,
            lastName: this.state.lastName
        }
        this.setState({
          isLoggedin: true,
          userDetails : userDetails
        })
        localStorage.getItem('users', JSON.stringify(this.state.userDetails));
        console.log(userDetails);
      }

    logout = (e) =>{
        e.preventDefault();
        this.setState({
          isLoggedin: false
        })
        localStorage.removeItem('users');
      }


  render()
  {
     
    return(
<div className='indexContainer'>
<Router>
<Navbar  expand="lg" className="navbar">
  <Container>
      <Nav>
      <ul className='listStyle'>
      <li>
      <img src={busicon} alt="" className='busiconimg'/>
      </li>
        <li>
        <Nav.Link href="/">Home</Nav.Link>
        </li>
        <li>
        <Nav.Link href="/routes">Routes</Nav.Link>  
        </li>
        <li>
        <Nav.Link href="/tickets">Support</Nav.Link>  
        </li>
        <li>
        <Nav.Link onClick={() => this.setState({ModalShowRegister: true})}> Register </Nav.Link>
        </li>
        {!this.state.isLoggedin ? (
        <div>
        <li>
        <form onSubmit={this.handleSubmit}>
      <Form.Group className='mb-3 col-lg-9'>
      <Row>
        <Col>
        <Form.Control type="text" placeholder="Username" 
        name="username" 
        onChange={e => this.setState({username:e.target.value})} 
        value={this.state.username}/>
        </Col>
        <Col>
        <Form.Control type="password" placeholder="Password" 
        password="password" 
        onChange={e => this.setState({password: e.target.value})} 
        value={this.state.password}/>
        </Col>
        <Col>
        <button className='button button1'> Log-in </button>
        </Col>
      </Row>
      </Form.Group>
    </form>
        </li>
        </div>
        ):(
            <div>
            <button onClick={this.logout}>logout</button> 
          </div>
        )}
      </ul>
      <LoginForm
        show={this.state.ModalShowLogin}
        onHide={() => this.setState({ModalShowLogin: false})}
      />
        <RegisterForm
        show={this.state.ModalShowRegister}
        onHide={() => this.setState({ModalShowRegister: false})}
      />
    </Nav>
  </Container>
</Navbar>
<Switch>
      <Route exact path="/" component={Home}/>
      <Route path="/routes" component={Routes}/>
      <Route path="/tickets" component={Tickets}/> 
      <Route path='/payment' component={Payment}/>
      <Route path='/receipt'component={Receipt}/>
      <Route component={Notfound}/>  {/* //if no route found it will just go directly into Notfound component */}
    </Switch>
</Router>
</div>
    )
  }
  
  
}

//login
class LoginForm extends React.Component {
    constructor(props){
        super(props)
        this.state= {
            username:'',
            password:'', 
            userDetails:[],
            isLoggedin: false
        }    
    }


    handleSubmit= (e) => {
      e.preventDefault();
        const items = JSON.parse(localStorage.getItem('users'));
      <Header 
      userDetails = {() => this.setState({userDetails: items})}
      isLoggedin ={() => this.setState({isLoggedin: true})}/>
    }
    

    
    render(){
    return (
      <Modal {...this.props} size="lg" aria-labelledby="contained-modal-title-vcenter" centered>
        <form onSubmit={this.handleSubmit}>
        <Modal.Header closeButton className='modalHeader'>
          <Modal.Title id="contained-modal-title-vcenter">
            Log-in
          </Modal.Title>
        </Modal.Header>
        
    <Modal.Body>
{/* <form onSubmit={this.handleSubmit}> */}
  <Form.Group className="mb-3" >
    <Form.Label>Username</Form.Label>
    <Form.Control type="text" placeholder="Enter your Username" 
    name="username" 
    onChange={e => this.setState({username:e.target.value})} 
    value={this.state.username}/>

    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Enter your password" 
    password="password" 
    onChange={e => this.setState({password: e.target.value})} 
    value={this.state.password}/>
  </Form.Group>
    </Modal.Body>

        <Modal.Footer>
        <p>Forgot Password?</p>
        <button>Log-in</button>
        </Modal.Footer>
        </form>
      </Modal>
    );
  }
}


//register
class RegisterForm extends React.Component {
            state= { 
                firstName: '',
                lastName: '',
                username:'',  usernameValid: false,
                password:'', passwordValid: false,
                passwordConfirm:'' , passwordConfirmValid: false,
                formValid: false,
                errorMsg: {}
            }

  //validation everytime a textbox are inputing value
  validateForm = () =>{
    const {usernameValid , passwordValid , passwordConfirmValid } = this.state;
    this.setState({
      formValid: usernameValid  && passwordValid && passwordConfirmValid
    })
  }
  
  //update the state of username and calling the validateUsername
  updateUsername = (username) => {
    this.setState({username},
    this.validateUsername
    )
  }
  
  //executing the validateUsername checking if char is 3 long
  validateUsername = () =>{
    const {username} = this.state;
    let usernameValid = true;
    let errorMsg = {...this.state.errorMsg} //cloning the errorMsg state
  
    if(username.length<3){
      usernameValid = false;
      errorMsg.username = 'Must be least 3 characters long'
    }
    this.setState({
      usernameValid,errorMsg
    }, this.validateForm)
  }



//update password state and calling validatePassword
updatePassword = (password) => {
    this.setState({password}, 
    this.validatePassword);
    }
    
  //executing the validatePassword
  validatePassword = () => {
    const {password} = this.state;
    let passwordValid = true;
    let errorMsg = {...this.state.errorMsg}
    
    // must be 6 chars
    // must contain a number
    // must contain a special character
    
    if (password.length < 6) {
        passwordValid = false;
        errorMsg.password = 'Password must be at least 6 characters long';
    } else if (!/\d/.test(password)){
        passwordValid = false;
        errorMsg.password = 'Password must contain a digit';
    } else if (!/[!@#$%^&*]/.test(password)){
        passwordValid = false;
        errorMsg.password = 'Password must contain special character: !@#$%^&*';
    }
    this.setState({passwordValid, errorMsg}, 
    this.validateForm);
    }
    
  
    //update passwordConfirm state and calling validatePasswordConfirm
  updatePasswordConfirm = (passwordConfirm) => {
    this.setState({passwordConfirm}, 
    this.validatePasswordConfirm)
    }
    
    //executing the validatePassword if the password and passwordConfirm match
    validatePasswordConfirm = () => {
    const {passwordConfirm, password} = this.state;
    let passwordConfirmValid = true;
    let errorMsg = {...this.state.errorMsg}
    
    if (password !== passwordConfirm) {
    passwordConfirmValid = false;
    errorMsg.passwordConfirm = 'Passwords do not match'
    }
    
    this.setState({passwordConfirmValid, errorMsg}, this.validateForm);
    }

    handleSubmit= () => {
        // e.preventDefault()
        let userDetails = {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            username: this.state.username,
            password: this.state.password
        }
        localStorage.setItem('users', JSON.stringify(userDetails));
        this.props.history.push('/')
        console.log('username: ' + this.state.username + ' password:' + this.state.password);
    }

    
    render(){
    return (
      <Modal {...this.props} size="lg" aria-labelledby="contained-modal-title-vcenter" centered>
        <form onSubmit={this.handleSubmit}>
        <Modal.Header closeButton className='modalHeader'>
          <Modal.Title id="contained-modal-title-vcenter">
            Register
          </Modal.Title>
        </Modal.Header>
        
    <Modal.Body>
{/* <form onSubmit={this.handleSubmit}> */}
  <Form.Group className="mb-3" >
  <Form.Label>First Name</Form.Label>
    <Form.Control type="text" placeholder="Enter your First Name" 
    name="firstName" 
    onChange={e => this.setState({firstName:e.target.value})} 
    value={this.state.firstName}/>

<Form.Label>Last name</Form.Label>
    <Form.Control type="text" placeholder="Enter your Last Name" 
    name="lastName" 
    onChange={e => this.setState({lastName:e.target.value})} 
    value={this.state.lastName}/>


    <Form.Label>Username</Form.Label>
    < ValidationMessage valid={this.state.usernameValid} message={this.state.errorMsg.username} />
    <Form.Control type="text" placeholder="Enter Username" 
    name="username" 
    onChange={(e) => this.updateUsername(e.target.value)} 
    value={this.state.username}/>

    <Form.Label>Password</Form.Label>
    < ValidationMessage valid={this.state.passwordValid} message={this.state.errorMsg.password} />
    <Form.Control type="password" placeholder="Enter password" 
    password="password" 
    onChange={(e) => this.updatePassword(e.target.value)} 
    value={this.state.password} id='password' name='password'/>

    <Form.Label>Confirm Password</Form.Label>
    < ValidationMessage valid={this.state.passwordConfirmValid} message={this.state.errorMsg.passwordConfirm} />
    <Form.Control type="password" placeholder="Password Confirm" 
    password="password" 
    onChange={(e) => this.updatePasswordConfirm(e.target.value)} 
    value={this.state.passwordConfirm} id='password-confirmation' name='password-confirmation'/>
  </Form.Group>
    </Modal.Body>

        <Modal.Footer>
        <button className='button button1' type='submit' disabled={!this.state.formValid}>Register</button>
        </Modal.Footer>
        </form>
      </Modal>
    );
  }
}

export default Header

