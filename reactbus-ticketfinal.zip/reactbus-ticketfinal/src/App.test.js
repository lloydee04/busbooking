// import { render, screen } from '@testing-library/react';
import { shallow, mount } from "enzyme";
import App from './App';
import Header from './Header'

it("renders correctly", () => {
  const wrapper = mount(<App />);
  expect(wrapper.state("error")).toEqual(null);
});


//shallow() uses for to check the component and it uses only for parent
it("renders without crashing", () => {
  shallow(<App />);
});

it("renders the header", () => {
  const wrapper = shallow(<App />);
  const header = <Header/>
  expect(wrapper.contains(header)).toEqual(true);
}); 