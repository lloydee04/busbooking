import React from 'react'
import logo from './imgnotfound.png'
import './css/notfound.css'
import {Button} from 'react-bootstrap';

class NotFound extends React.Component{
    render(){
    return(
        <div className='notfoundContainer'>
        <img src={logo} alt='logo'/>
        <h1 className='titleText'>PAGE NOT FOUND</h1>
        <p>We looked everywhere for this page</p>
        <p>Are you sure the website URL is correct?</p>
        <p>Get in touch with the site owner</p>
        <Button href='/' variant="outline-primary">Go Back Home</Button>
        </div>
    
    )
}
}

export default NotFound