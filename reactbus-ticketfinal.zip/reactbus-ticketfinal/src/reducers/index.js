import { combineReducers } from 'redux';
import {SEARCH_BUS, GET_ALL_PRODUCT } from  '../actions';

const initState = {
    _buses:[],
}

function todoBus(state = initState, action){
    switch(action.type){
        //i remove the search function cause its so scuffed, it is working but not the way it is.
        case SEARCH_BUS:
            const reg = new RegExp(`${action.payload}`, 'i')
            return{
             ...state,
             buses: state._buses.filter(bus => bus.busName.match(reg))
            }
            case GET_ALL_PRODUCT: 
            return{
                ...state,
                _buses:action.payload
            }
        default:
            return state;
    }
}
const BusApp = combineReducers({
    _todoBus: todoBus
});
export default BusApp;