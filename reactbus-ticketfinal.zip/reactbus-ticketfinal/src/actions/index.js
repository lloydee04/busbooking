// import callApi from '../api'
export const SEARCH_BUS = 'SEARCH_BUS';
export const GET_ALL_PRODUCT = 'GET_ALL_PRODUCT';

/*SEARCH PRODUCT*/
export function SearchBus(payload){
    return{
        type:'SEARCH_BUS',
        payload
    }
}

/*GET_ALL_PRODUCT*/
export function GetAllProduct(payload){
    return{
        type:'GET_ALL_PRODUCT',
        payload
    }
}

// export const actFetchProductsRequest = () => {
//     return (dispatch) => {
//         return callApi('bus', 'GET', null).then(res => {
          
//             dispatch(GetAllProduct(res.data));
//         });
//     }
// }