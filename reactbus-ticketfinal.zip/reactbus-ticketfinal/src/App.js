import React from 'react'
import './App.css'
import Header from './Header'

class App extends React.Component{
  state= { 
    username:'',
    password:'',
    isLoggedin: false,
}

  render()
  {
     
return(
<div className='indexContainer'>
      <Header/>
</div>
    )
  }
  
}

export default App

