import React, {useState, useEffect} from 'react'
import './routes.css'
import {Table, Modal, Badge, Form, Col , Row } from 'react-bootstrap'
import {Link} from 'react-router-dom';


function Routes (){

  const buses = [{
    "busId": "9781593275846",
    "busName": "VGO Bus",
    "image": "https://gst-contracts.s3.amazonaws.com/uploads/bcc/cms/asset/avatar/129831/gallery_g3.png",
    "fare": 20,
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2022-07-14",
    "departure_date": "2022-07-14",
    "destination_from": "Manila",
    "destination_to": "Bicol",
},
{
    "busId": "9887563372846",
    "busName": "Gujarat Travels",
    "image": "https://i.ytimg.com/vi/voJyS5qny90/sddefault.jpg",
    "fare": 15,
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2022-07-14",
    "departure_date": "2022-07-14",
    "destination_from": "Manila",
    "destination_to": "Bulacan",
},
{
    "busId": "9382563802846",
    "busName": "Ramdev Tours And Travels",
    "image": "https://st.redbus.in/bo-images/IND/WM/10162/54/FR/L/4uZ8yo.jpeg",
    "fare": 20,
    "duration": '20 Hours',
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2022-07-14",
    "departure_date": "2022-07-14",
    "destination_from": "Manila",
    "destination_to": "Bagiuo",
},
{
    "busId": "8182966882816",
    "busName": "Shrinath® Travel Agency Pvt. Ltd.",
    "image": "https://image3.mouthshut.com/images/imagesp/925816129s.jpg",
    "fare": 35,
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2022-07-14",
    "departure_date": "2022-07-14",
    "destination_from": "Manila",
    "destination_to": "Pampanga",
},
{
    "busId": "8183966782836",
    "busName": "Force Motors",
    "image": "https://commercialvehicle.in/wp-content/uploads/2018/12/DSC3639-copy.jpg",
    "fare": 25,
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2022-07-14",
    "departure_date": "2022-07-14",
    "destination_from": "Manila",
    "destination_to": "Laguna",
},
{
    "busId": "9681449531888",
    "busName": "Hans Travels (I) Private Limited",
    "image": "https://s3-ap-southeast-1.amazonaws.com/rbplus/BusImage/Domestic/8842_16_1.png",
    "fare": 23,
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2012-07-01",
    "departure_date": "2022-07-01",
    "destination_from": "Manila",
    "destination_to": "Cavite",
},
{
    "busId": "9581349265135",
    "busName": "BharatBenz",
    "image": "https://www.team-bhp.com/forum/attachments/commercial-vehicles/1786421d1533217593-glider-premium-bus-bharatbenz-dealer-autobahn-launch4.jpg",
    "fare": 20,
    "seatsAvailable": 20,
    "duration": '20 Hours',
    "arrival_date": "2022-07-01",
    "departure_date": "2022-07-01",
    "destination_from": "Manila",
    "destination_to": "Antipolo",
},
{
    "busId": "9481429335475",
    "busName": "Chanakya Travels Agency",
    "image": "https://gst-contracts.s3.amazonaws.com/uploads/bcc/cms/asset/avatar/11590/gallery_34299814356_f8d9567135_n.jpg",
    "duration": '20 Hours',
    "fare": 30,
    "seatsAvailable": 20,
    "arrival_date": "2022-07-01",
    "departure_date": "2022-07-01",
    "destination_from": "Manila",
    "destination_to": "Capiz",
},

];


const [value , setValue] = useState('')
const [value1 , setValue1] = useState('')
const [dataSource , setDataSoruce] = useState(buses)
const [tableFilter,setTableFilter] = useState([]);
const [modalShow, setModalShow] = React.useState(false);

// useEffect(() => {
//   fetch("http://localhost:4600/bus")
//   .then(response => response.json())
//       // 4. Setting *dogImage* to the image url that we received from the response above
//   .then(data => setDogImage(data.message))
// },[])


const filterData = (e) => {
  if(e.target.value !== ""){
    setValue(e.target.value);
    const filterTable = dataSource.filter(o => Object.keys(o).some(k=>
      String(o[k]).toLowerCase().includes(e.target.value.toLowerCase())));
      setTableFilter([...filterTable])
  }
  else{
    setValue(e.target.value);
    setDataSoruce([...dataSource])
  }
}

const filterData1 = (e) => {
  if(e.target.value !== ""){
    setValue1(e.target.value);
    const filterTable = dataSource.filter(o => Object.keys(o).some(k=>
      String(o[k]).toLowerCase().includes(e.target.value.toLowerCase())));
      setTableFilter([...filterTable])
  }
  else{
    setValue1(e.target.value);
    setDataSoruce([...dataSource])
  }
}

        return(
  <div className='containerTable'>
    <div className='containerBody1'>
    <form>
    <Form.Group className='mb-3 col-lg-12'>
      <h4>Search Bus Routes</h4>
          <Row>
          <Col>
          <Form.Control placeholder="FROM" value={value} onChange={filterData}/>
        </Col>
        <Col>
          <Form.Control placeholder="TO" value={value1} name='to' onChange={filterData1}/>
        </Col>  
      </Row>
      </Form.Group>
      </form>
            <Table striped bordered hover>
            <thead className='tableHead'>
                <th className='textHead'>Bus Name</th>
                <th className='textHead'>Bus Image</th>
                <th className='textHead'>FROM</th>
                <th className='textHead'>TO</th>
                <th className='textHead'>Arrival Date</th>
                <th className='textHead'>Departure Date</th>
                <th className='textHead'>Seats Available</th>
                <th className='textHead'>Duration</th>
                <th className='textHead'>Fare</th>
                <th></th>
            </thead>
                {value.length> 0 ? tableFilter.map((bus, index) => {
                  return(
                    <tbody>
                    <tr className='textBody' key={index}>
                        <td className='textD'>{bus.busName}</td>
                        <td><img src={bus.image} alt="" className="image"/></td>
                        <td>{bus.destination_from}</td>
                        <td>{bus.destination_to}</td>
                        <td>{bus.arrival_date}</td>
                        <td>{bus.departure_date}</td>
                        <td>{bus.seatsAvailable}</td>
                        <td>{bus.duration}</td>
                        <td>{bus.fare}$</td>
                        {/* <td ><button onClick={() => this.setState({ModalShowRegister: true})} className='button button1'>Show Seats</button></td> */}
                        <td ><button onClick={() => setModalShow(true)} className='button button1'>Show Seats</button></td>
                    </tr>
                    </tbody>
                  )
                })
                  :
                  dataSource.map((bus, index) => {
                  return(
                    <tbody>
                    <tr className='textBody' key={index}>
                        <td className='textD'>{bus.busName}</td>
                        <td><img src={bus.image} alt="" className="image"/></td>
                        <td>{bus.destination_from}</td>
                        <td>{bus.destination_to}</td>
                        <td>{bus.arrival_date}</td>
                        <td>{bus.departure_date}</td>
                        <td>{bus.seatsAvailable}</td>
                        <td>{bus.duration}</td>
                        <td>{bus.fare}$</td>
                        {/* <td ><button onClick={() => this.setState({ModalShowRegister: true})} className='button button1'>Show Seats</button></td> */}
                        <td ><button onClick={() => setModalShow(true)} className='button button1'>Show Seats</button></td>
                    </tr>
                    </tbody>
                  )
                }
                  )
              }
                
            </Table>
            <ShowSeats
            buses = {tableFilter}
            show= {modalShow}
            onHide= {() => setModalShow(false)}
            />
            </div>
            </div>
        )
}

function ShowSeats (props) {
  const [seatLocation, setSeatLocation] = useState("");
  const buses = props.buses
  const busname = buses.map((bus) => <p>{bus.busName}</p>);
  const seatNum = buses.map((bus) => <p>{bus.seatsAvailable}</p>);
    return(
    <div>
    <Modal {...props} size="lg" aria-labelledby="contained-modal-title-vcenter" centered >
        <form>
        <Modal.Header closeButton className='modalHeader'>
            <Modal.Title id="contained-modal-title-vcenter">Available Seats:{seatNum} {busname}</Modal.Title>
        </Modal.Header> 

        <Modal.Body>
<Form.Group onChange={e => setSeatLocation(e.target.value)} value={seatLocation}>

<div className="bus seat2-2 border-0 p-0">
  <div className="seat-row-1">
    <ol className="seats">
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-1"  value="1" required="" type="radio"/>
        <label for="seat-radio-1-1">1</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-2"  value="2" required="" type="radio"/>
        <label for="seat-radio-1-2">2 </label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-3"  value="3" required="" type="radio"/>
        <label for="seat-radio-1-3">3</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-4"  value="4" required="" type="radio"/>
        <label for="seat-radio-1-4">4 </label>
      </li>
    </ol>
  </div>
  <div className="seat-row-2">
    <ol className="seats">
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-5"  value="5" required="" type="radio"/>
        <label for="seat-radio-1-5">5</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-6"  value="6" required="" type="radio"/>
        <label for="seat-radio-1-6">6</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-7"  value="7" required="" type="radio"/>
        <label for="seat-radio-1-7">7</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-8"  value="8" required="" type="radio"/>
        <label for="seat-radio-1-8">8</label>
      </li>
    </ol>
  </div>
  <div className="seat-row-3">
    <ol className="seats">
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-9"  value="9" required="" type="radio"/>
        <label for="seat-radio-1-9">9</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-10"  value="10" required="" type="radio"/>
        <label for="seat-radio-1-10">10</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-11"  value="11" required="" type="radio"/>
        <label for="seat-radio-1-11">11</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-12"  value="12" required="" type="radio"/>
        <label for="seat-radio-1-12">12</label>
      </li>
    </ol>
  </div>
  <div className="seat-row-4">
    <ol className="seats">
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-13"  value="13" required="" type="radio"/>
        <label for="seat-radio-1-13">13</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-14"  value="14" required="" type="radio"/>
        <label for="seat-radio-1-14">14</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-15" value="15" required="" type="radio"/>
        <label for="seat-radio-1-15">15</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-16"  value="16" required="" type="radio"/>
        <label for="seat-radio-1-16">16 </label>
      </li>
    </ol>
  </div>
  <div className="seat-row-5">
    <ol className="seats">
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-17"  value="17" required="" type="radio"/>
        <label for="seat-radio-1-17">17</label>
      </li>
      <li className="seat">
        <input  name="passengers[1][seat]" id="seat-radio-1-18"  value="18" required="" type="radio"/>
        <label for="seat-radio-1-18">18</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-19"  value="19" required="" type="radio"/>
        <label for="seat-radio-1-19">19</label>
      </li>
      <li className="seat">
        <input name="passengers[1][seat]" id="seat-radio-1-20"  value="20" required="" type="radio"/>
        <label for="seat-radio-1-20">20</label>
      </li>
    </ol>
  </div>
</div>
</Form.Group>
        </Modal.Body>

        <Modal.Footer>
        <div class='text-left'>
        <Badge bg="primary">Available</Badge>{' '}
        <Badge bg="success">Chosen</Badge> {' '}
        <Badge bg="danger">Occupied</Badge>{' '}
        </div>
        <Link to={{
        pathname: "/payment",
        state : {
          buses: props.buses,
          seatLocation: seatLocation
        }
      }}>
        <button className='button button1'>Proceed to Payment</button>
        </Link>
        </Modal.Footer>
        </form>

      </Modal>
      </div>
        ) 
}



export default Routes