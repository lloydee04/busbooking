import React,{useState} from 'react';
import {Form, Col, Row, Collapse } from 'react-bootstrap';
import {Link, useLocation} from 'react-router-dom';
import './payment.css';
import arrowdown from './arrow-down.png'
import gcash from './gcash.png';
import paypal from './paypal.png';
import mastercard from './mastercard.png';

function Payment (){
  const location = useLocation()
  const buses = location.state?.buses
  const seatLocation = location.state?.seatLocation
  const [openPassenger, setOpenPassenger] = useState(false);
  const [openContact, setOpenContact] = useState(false);
  const [openPayment1, setOpenPayment1] = useState(false);
  const [openPayment2, setOpenPayment2] = useState(false);
  const [openPayment3, setOpenPayment3] = useState(false);
  const [fName, setfName] = useState("");
  const [lName, setlName] = useState("");
  const [address, setAddress] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [modeofPayment, setmodeofPayment] = useState("");
  const [validated, setValidated] = useState(false);

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };
  console.log(seatLocation)
  // console.log(buses);
        return(
        <div className='paymentContainer'>
            <h2>Payment</h2>
      <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <div className='paymentBody'>
    
      <h4 
        onClick={()=> setOpenPassenger(!openPassenger)}
        aria-expanded={false}
        aria-controls="example-collapse-text"
      >Passenger Information
      <img src={arrowdown} alt="" className='arrowdownImg'/></h4>
    <Collapse in={openPassenger}>
    <div id="example-collapse-text">
      <Row className="mb-3">
        <Form.Group as={Col} controlId="firstName">
          <Form.Label>First Name</Form.Label>
          <Form.Control type="text" placeholder="First Name" required onChange={e => setfName(e.target.value)} value={fName} name="fName"/>
        </Form.Group> 

        <Form.Group as={Col} controlId="lastName">
          <Form.Label>Last Name</Form.Label>
          <Form.Control type="text" placeholder="Last Name" required onChange={e => setlName(e.target.value)} value={lName} name="lName"/>
        </Form.Group>
      </Row>
        
    <Row>
    <Col>
      <Form.Group className="mb-3" controlId="address">
        <Form.Label>Address</Form.Label>
        <Form.Control placeholder="Address" required onChange={e => setAddress(e.target.value)} value={address} name="address"/>
      </Form.Group>
    </Col>
    <Col>
      <Form.Group className="mb-3" controlId="age">
        <Form.Label>Age</Form.Label>
        <Form.Control placeholder="Age" required  onChange={e => setAge(e.target.value)} value={age} name="age"/>
      </Form.Group>
    </Col>
    <Col>
    <Form.Group className="mb-3" controlId="gender" onChange={e => setGender(e.target.value)} value={gender} name="gender">
    <Form.Label>Gender</Form.Label>
        <Form.Check  value="Male" type='radio' name ="gender" label="Male" required/>
        <Form.Check  value="Female" type='radio' name = "gender" label="Female" required/>
    </Form.Group>
    </Col>
    </Row>
    </div>
    </Collapse>
    </div>

    <div className='paymentBody'>
      <h4 
        onClick={()=> setOpenContact(!openContact)}
        aria-expanded={false}
        aria-controls="example-collapse-text"
      >Contact Details
      <img src={arrowdown} alt="" className='arrowdownImg'/></h4>
    <Collapse in={openContact}>
    <div id="example-collapse-text">
      <Row className="mb-3">
        <Form.Group as={Col} controlId="formGridfName">
          <Form.Label>Email</Form.Label>
          <Form.Control type="text" placeholder="Email" required onChange={e => setEmail(e.target.value)} value={email}/>
        </Form.Group>
        <Form.Group as={Col} controlId="formGridlName">
          <Form.Label>Phone Number</Form.Label>
          <Form.Control type="text" placeholder="Phone Number" required onChange={e => setPhoneNumber(e.target.value)} value={phoneNumber}/>
        </Form.Group>
      </Row>

    </div>
    </Collapse>
    </div>
    {/* onChange={e => this.setState({gender: e.target.value})} value={this.state.gender} name="gender" */}
    <div className='paymentBody'>
    <h4>Payment Method</h4>
    <Form.Group onChange={e => setmodeofPayment(e.target.value)} value={modeofPayment} name="paymentMode">
    <Form.Check  
    onClick={()=> setOpenPayment1(!openPayment1)}
    aria-expanded={false}
    aria-controls="example-collapse-text"
    inline value="Gcash" type='radio' name ="paymentMode" id="gcashId" /><img src={gcash} alt="" className='paymentImg'/>
    <Collapse in={openPayment1}>
    <div id="example-collapse-text">
      <Row className="mb-3">
        <Form.Group as={Col} controlId="formGridlName" >
          <Form.Label>Phone Number</Form.Label>
          <Form.Control type="text" placeholder="Phone Number" disabled/>
        </Form.Group>
      </Row>
    </div>
    </Collapse>

    <Form.Check  
    onClick={()=> setOpenPayment2(!openPayment2)}
    aria-expanded={false}
    aria-controls="example-collapse-text"
    inline value="Paypal" type='radio' name = "paymentMode" id="paypalId"/> <img src={paypal} alt="" className='paymentImg'/>
    <Collapse in={openPayment2}>
    <div id="example-collapse-text">
      <Row className="mb-3">
        <Form.Group as={Col} controlId="formGridfName">
          <Form.Label>Email</Form.Label>
          <Form.Control type="text" placeholder="Email" disabled/>
        </Form.Group>
      </Row>
    </div>
    </Collapse>


    <Form.Check  
    onClick={()=> setOpenPayment3(!openPayment3)}
    aria-expanded={false}
    aria-controls="example-collapse-text"
    inline value="Mastercard" type='radio' name = "paymentMode" id="mastercardId"/> <img src={mastercard} alt="" className='paymentImg'/>
    <Collapse in={openPayment3}>
    <div id="example-collapse-text">
      <Row className="mb-3">
        <Form.Group as={Col} controlId="formGridfName">
          <Form.Label>Credit Card Number</Form.Label>
          <Form.Control type="text" placeholder="Card Number" disabled/>
        </Form.Group>
        <Form.Group as={Col} controlId="formGridlName">
          <Form.Label>Name of Card</Form.Label>
          <Form.Control type="text" placeholder="Name of Card" disabled/>
        </Form.Group>
      </Row>
      <Row className="mb-3">
        <Col>
        <Form.Group controlId="formGridfName">
          <Form.Label>Expiry Date</Form.Label>
          <Form.Control type="text" placeholder="Month" disabled/>
        </Form.Group>
        </Col>
        <Col>
        <Form.Group controlId="formGridlName">
          <Form.Label></Form.Label>
          <Form.Control type="text" placeholder="Year" disabled/>
        </Form.Group>
        </Col>
        <Col>
        <Form.Label></Form.Label>
        <Form.Group  controlId="formGridlName">
          <Form.Control type="text" placeholder="CVV Number" disabled/>
        </Form.Group>
        </Col>
      </Row>
    </div>
    </Collapse>
    </Form.Group>
    </div>

      <Link to={{
        pathname: "/receipt",
        state : {
          fName: fName,
          lName: lName,
          address: address,
          age: age,
          gender: gender,
          phoneNumber: phoneNumber,
          email: email,
          modeofPayment: modeofPayment,
          buses: buses,
          seatLocation: seatLocation
        }
      }}
        >
        <button type="submit" className='button button1'>Check Out</button>
      </Link>
        </Form>
    </div>
        )
    // }
}


export default Payment




