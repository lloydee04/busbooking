import React from 'react'
import './home.css'
import {Col , Row , Form, Card} from 'react-bootstrap'
import {Link} from 'react-router-dom';
import axios from 'axios';

class Home extends React.Component{
  constructor(){
    super()
    this.state ={
      destination_from : '',
      destination_to : '',
      date: '',
      buses:[],
      userDetails:[],
    }
  }

componentDidMount(){
  const items = JSON.parse(localStorage.getItem('users'));
    axios.get(`http://localhost:4600/bus`)
    .then(res => {
        const buses = res.data;
        this.setState({
          buses,
          userDetails: items
        });
        console.log(this.state.buses);
        console.log(items)
    })

}

onSearch = async(e) =>{
  const bus = {
    destination_from : this.state.destination_from,
    destination_to: this.state.destination_to,
    date: this.state.date
  }
  e.preventDefault();
  await axios.get(`http://localhost:4600/bus?q=${bus}`)
  .then(res => {
      const buses = res.data.result;
      this.setState({
        buses
      });
      console.log(this.state.buses);
  })
}

  render()
  { 
    return(
        <div className='containerBody'>
          <h3>Bus Booking System</h3>
        <div className='formSearchBus'>
        <Form.Group className='mb-3 col-lg-12'>
        <form onSubmit={this.onSearch}>
          <Row>
          <Col>
          <Form.Control placeholder="FROM" onChange={e => this.setState({destination_from: e.target.value})} value={this.state.destination_from}/>
        </Col>
        <Col>
          <Form.Control placeholder="TO" onChange={e => this.setState({destination_to: e.target.value})} value={this.state.destination_to}/>
        </Col>  
        <Col>
          <Form.Control placeholder="ONWARD DATE" type='date' onChange={e => this.setState({date: e.target.value})} value={this.state.date}/>
        </Col>
        <Col>
        <Link to='/routes'>
          <button className='button button1'> Search Routes </button>
        </Link>
        </Col>
      </Row>
    </form>
      </Form.Group>
        </div>
      <div>
        <h2>Agency Partners</h2>
      </div>
      <div className='cardsContainer'>
      {this.state.buses.map(bus=>

      <Card style={{ width: '18rem' }} className='cards'>
      <Card.Img variant="top" src={bus.image} className="cardImage" alt="" />
      <Card.Body>
        <Card.Title>{bus.busName}</Card.Title>
      </Card.Body>
    </Card>
          )}
        </div>
      </div>
    )
  }
}

export default Home
