import React, {useRef} from 'react';
import { useLocation, Link } from "react-router-dom";
import { useReactToPrint } from 'react-to-print';
// import Printer, { print } from 'react-pdf-print';
import './receipt.css';

function Receipt (){
    const componentRef = useRef()
    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
    })
    // const ids = ['1']
    const location = useLocation()
    const buses = location.state?.buses
    const fName = location.state?.fName
    const lName = location.state?.lName
    const seatLocation = location.state?.seatLocation
    const address = location.state?.address
    const age = location.state?.age
    const gender = location.state?.gender
    const phoneNumber = location.state?.phoneNumber
    const email = location.state?.email
    const modeofPayment = location.state?.modeofPayment
    const busname = buses.map((bus) => <p>{bus.busName}</p>);
    const from = buses.map((bus) => <p>{bus.destination_from}</p>);
    const to = buses.map((bus) => <p>{bus.destination_to}</p>);
    const departure_date = buses.map((bus) => <p>{bus.departure_date}</p>);
    const fare = buses.map((bus) => <p>{bus.fare}$</p>);
    console.log(fName + lName);
    console.log(buses);
        // const {details} = this.props.paymentForm;
        return(
            // <Printer>
            <div className='containerBody' >
                {/* {buses.map(bus => */}
                    
                <div className='containerBody1' ref={componentRef} style={{width: '100%'}}>
                    <h4>Passenger Receipt</h4>
                    <h3>Reference Number: #{Math.ceil(Math.random()* 2458723849) +2458723849}</h3>
                    <div>
                    <ul className='listStyle'>
                        <li>
                    Bus Name: <b>{busname}</b>
                        </li>
                        <li>
                    FROM: <b>{from}</b>
                        </li>
                        <li>
                    TO: <b>{to}</b>
                        </li>
                        <li>
                    Departure Date: <b>{departure_date}</b>
                        </li>
                        <li>
                    Seat Number: <b><p>{seatLocation}</p></b>
                        </li>
                        <li>
                    Fare: <b>{fare}</b>
                        </li>
                    </ul>
                    </div>
                    <p>Name: {fName} {lName}</p> 
                    <p>Address: {address}</p>
                    <p>Age: {age}</p>
                    <p>Gender: {gender}</p>
                    <p>Phone Number: {phoneNumber}</p>
                    <p>Email: {email}</p>
                    <p>Mode of Payment: {modeofPayment}</p>
                </div>
                <button onClick={handlePrint} style={{ position: 'relative', float: 'right' }} className='button button1'>Print Receipt</button>
                    {/* <input type='button' style={{ position: 'relative', float: 'right' }}
                    onClick={() => print(ids)} value='Print' /> */}
                    <Link to='/'>
                    <button className='button button1'>Back to Homepage</button>
                    </Link>
            {/* )} */}
            </div>
            // </Printer>
        )
}

export default Receipt